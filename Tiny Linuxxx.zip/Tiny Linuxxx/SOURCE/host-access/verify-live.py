from pathlib import Path
import ftplib,time,subprocess,json,hashlib,uuid,sys
root=Path(__file__).resolve().parent;e=root/'evidence'/(sys.argv[1] if len(sys.argv)>1 else 'round2');e.mkdir(exist_ok=True)
def fetch(name):
 f=ftplib.FTP();f.connect('192.168.77.2',2121,timeout=10);f.login();f.sendcmd('SELF');data=bytearray();f.retrbinary('RETR /data/tiny-linux-title.log',data.extend);f.quit();(e/name).write_bytes(data);return bytes(data)
start=time.time();deadline=time.monotonic()+240
while time.monotonic()<deadline:
 data=fetch('title-boot.log')
 if b'PS5_LINUX_SELFTEST_OK\r' in data or b'PS5_LINUX_SELFTEST_OK\n' in data:break
 time.sleep(5)
else:raise SystemExit('boot not verified; no command sent')
marker='bridge-'+uuid.uuid4().hex[:12];path='/data/tiny-linux-'+marker+'.txt'
command=f'ps5ctl status; ps5ctl status; ps5ctl put {path} {marker}; ps5ctl read {path}; ps5ctl net; free; echo BRIDGE_TEST_DONE'
(e/'live-command.txt').write_text(command+'\n')
r=subprocess.run(['python3',str(root/'send-command.py'),command],capture_output=True,text=True);(e/'sender.log').write_text(r.stdout+r.stderr)
if r.returncode:raise SystemExit('sender returned failure; inspect before any retry')
deadline=time.monotonic()+150
while time.monotonic()<deadline:
 data=fetch('title-test.log');delta=data.split(b'[APP] Linux shell self-test PASSED',1)[-1]
 if b'\nBRIDGE_TEST_DONE\r' in delta or b'\nBRIDGE_TEST_DONE\n' in delta:break
 time.sleep(5)
else:raise SystemExit('native test execution not verified; do not retry')
f=ftplib.FTP();f.connect('192.168.77.2',2121,timeout=10);f.login();f.sendcmd('SELF');content=bytearray();f.retrbinary('RETR '+path,content.extend);assert bytes(content)==marker.encode()
checks=[];manifest=json.loads((root/'release/PPSA99994/manifest.json').read_text())
for prefix in ['/data/homebrew/PPSA99994','/system_ex/app/PPSA99994']:
 for rel,want in manifest.items():
  h=hashlib.sha256();f.retrbinary('RETR '+prefix+'/'+rel,h.update);assert h.hexdigest()==want;checks.append({'path':prefix+'/'+rel,'sha256':want})
f.quit()
assert b'PS5 host response=1' in delta and b'PS5 host response=2' in delta
assert marker.encode() in delta
result={'started':start,'finished':time.time(),'command':command,'native_marker_readback':True,'marker_path':path,'marker':marker,'checks':checks,'limitations':['Wi-Fi association and Bluetooth control unavailable','network flags changes not live-tested','file put creates new files only','single client only']}
(e/'live-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
