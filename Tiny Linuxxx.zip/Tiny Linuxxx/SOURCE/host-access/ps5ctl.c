/* Freestanding RV32 guest client: O_DIRECT prevents stale block-cache replies. */
typedef unsigned int size_t;
static long call(long n,long a,long b,long c) {
 register long a0 __asm__("a0")=a,a1 __asm__("a1")=b,a2 __asm__("a2")=c;
 register long a7 __asm__("a7")=n;
 __asm__ volatile("ecall":"+r"(a0):"r"(a1),"r"(a2),"r"(a7):"memory");return a0;
}
static unsigned char request[512] __attribute__((aligned(4096)));
static unsigned char response[8192] __attribute__((aligned(4096)));
static void out(const char *s) {size_t n=0;while(s[n])n++;call(64,1,(long)s,n);}
int main(int argc,char **argv) {
 const char *magic="PS5CTL1\n";unsigned n=0;
 while(n<8){request[n]=magic[n];n++;}
 if(argc<2){out("Usage: ps5ctl help\n");return 1;}
 for(int i=1;i<argc;i++) {
  if(i>1){if(n>=511)goto bad;request[n++]=' ';}
  for(unsigned j=0;argv[i][j];j++) {
   unsigned char c=argv[i][j];if(c<32||c>126||n>=511)goto bad;
   request[n++]=c;
  }
 }
 /* openat(AT_FDCWD, path, O_RDWR|O_DIRECT). Device must be block-special. */
 long fd=call(56,-100,(long)"/dev/vdb",2|040000);
 if(fd<0){out("ps5ctl: cannot open local PS5 bridge\n");return 1;}
 if(call(64,fd,(long)request,512)!=512){out("ps5ctl: bridge write failed\n");call(57,fd,0,0);return 1;}
 /* Offset is now 512: reading response immediately follows request sector. */
 long got=call(63,fd,(long)response,8192);call(57,fd,0,0);
 if(got!=8192){out("ps5ctl: bridge read failed\n");return 1;}
 response[8191]=0;out((char*)response);
 return response[0]=='E'&&response[1]=='R'&&response[2]=='R'?1:0;
 bad:out("ps5ctl: use 1-503 printable ASCII command bytes\n");return 1;
}
__attribute__((naked,noreturn)) void _start(void) {
 __asm__ volatile("lw a0,0(sp)\naddi a1,sp,4\ncall main\nli a7,93\necall\n");
}
