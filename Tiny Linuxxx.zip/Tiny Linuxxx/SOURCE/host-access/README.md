PS5 local host bridge candidate

Private workspace build forked from codex-c final command-injection ce6be2ff.
No new network listener, Ethernet emulation, routing changes or guest network access.
Guest /usr/bin/ps5ctl is a freestanding RV32 binary using aligned O_DIRECT block I/O.
/dev/vdb is 17 sectors. Sector 0: PS5CTL1 newline + NUL-terminated printable request,
max 503 bytes. Sectors 1-16: NUL-terminated native reply. Writes execute synchronously.
One client at a time. Guest root can speak this interface; it is not an authorization
boundary against guest code. Host operations run with the app's existing permissions.

Commands: ps5ctl help/status/net/stat/read/put. net IFACE up/down uses native ioctl
and verifies returned flags, but does not configure Wi-Fi association or IP/routing.
read/stat and create-new put support /data/ and /mnt/usb0/ paths. Existing files are
preserved. No arbitrary shell execution or system-file overwrite is implemented.
Bluetooth and Wi-Fi pairing/association explicitly report unavailable. These require
further supported native API development; the broad operator request remains incomplete.
RAM: reserve 256 MiB before emulator initialization; fall back 128/64 on allocation
failure. Root disk, framebuffer and app heap are separate. Guest usable RAM is smaller
than the allocation. Host emulator test yielded 186740 KiB MemTotal with 256MiB target.

Build: python3 build-title.py. Guest client source ps5ctl.c; compile with clang
--target=riscv32-linux-gnu -march=rv32imac -mabi=ilp32 -O2 -fno-builtin
-fno-stack-protector -nostdlib -static -fuse-ld=lld -Wl,-e,_start,--no-relax.
Embed ps5ctl-rv32 as /usr/bin/ps5ctl in private runtime/root-riscv32.bin using debugfs.
Tests in tests/: test-bridge under ASan/UBSan checks bounds/rejection and fresh responses;
test-host checks parser and status; evidence/host-boot.log shows two distinct guest-side
O_DIRECT round trips to mock native operation and shell completion. This is local
transport verification, not PS5 native execution. Runtime evidence recorded separately.
Native round1 installed cd522f24: 256MiB direct allocation succeeded; MemTotal=186740KiB.
48MiB tmpfs write/read-memory accounting and cleanup succeeded (~28 seconds write).
Two distinct guest requests reached native PID238; uid1; FreeBSD amd64 identity;
native /data marker content independently read back over FTP; native getifaddrs
reported eth0 192.168.77.2. Native ioctl interface flags denied errno13, even read.
So net IFACE up/down is NOT verified working; only net listing is live verified.
Review-fix candidate disables all HEN publication/cancellation; startup retains existing
permissions. Re-enabling requires a documented available handler and ownership-safe protocol.
File operations walk every component relative to directory descriptors, rejecting symlinks,
empty components and dot traversal. Network updates compare actual IFF_UP to requested state.
These fixes are locally tested; the installed round2 release remains the earlier candidate.
Source/release pins: evidence/candidate-hashes.json. Prior runtime evidence: evidence/round1.
The old shell dd client is retained only as ps5ctl-dd-obsolete.sh; it is NOT installed.
