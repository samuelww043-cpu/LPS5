from pathlib import Path
import ftplib,hashlib,json,datetime
root=Path(__file__).resolve().parent; bundle=root/'release/PPSA99994'; evidence=root/'evidence'
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
manifest=json.loads((bundle/'manifest.json').read_text())
for rel,want in manifest.items():
 assert hashlib.sha256((bundle/rel).read_bytes()).hexdigest()==want,rel
f=ftplib.FTP();f.connect('192.168.77.2',2121,timeout=15);f.login();f.sendcmd('SELF')
active='/data/homebrew/PPSA99994';stage='/data/homebrew/.PPSA99994-new-'+stamp;backup='/data/homebrew/.PPSA99994-backup-'+stamp
result={'utc':stamp,'active':active,'stage':stage,'rollback':backup,'checks':[],'activated':False}
def save(): (evidence/'result.json').write_text(json.dumps(result,indent=2))
f.mkd(stage)
for directory in ['sce_module','sce_sys','LICENSES']: f.mkd(stage+'/'+directory)
for path in sorted(bundle.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(bundle).as_posix();remote=stage+'/'+rel
 with path.open('rb') as stream:f.storbinary('STOR '+remote,stream,262144)
 if rel=='eboot.bin': f.sendcmd('SITE CHMOD 755 '+remote)
 h=hashlib.sha256();f.retrbinary('RETR '+remote,h.update,262144)
 assert h.hexdigest()==hashlib.sha256(path.read_bytes()).hexdigest(),rel
 result['checks'].append({'path':rel,'sha256':h.hexdigest()});save();print('verified staged',rel,flush=True)
f.rename(active,backup);result['old_preserved']=True;save()
try:f.rename(stage,active)
except Exception:
 f.rename(backup,active);result['rolled_back']=True;save();raise
result['activated']=True;save()
for check in result['checks']:
 h=hashlib.sha256();f.retrbinary('RETR '+active+'/'+check['path'],h.update,262144);assert h.hexdigest()==check['sha256']
result['installed_readback_verified']=True;save();f.quit();print(json.dumps(result,indent=2))
