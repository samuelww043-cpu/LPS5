#include <stddef.h>
int ps5_host_command(const char *,char *,size_t);
