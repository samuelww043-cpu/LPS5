#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "host_control.h"
int main(void){char r[8192];assert(!ps5_host_command("status",r,sizeof(r)));assert(strstr(r,"response=1"));assert(!ps5_host_command("status",r,sizeof(r)));assert(strstr(r,"response=2"));assert(ps5_host_command("read /x",r,sizeof(r))<0);assert(ps5_host_command("read /data/../etc/passwd",r,sizeof(r))<0);assert(ps5_host_command("put /data/test",r,sizeof(r))<0);assert(ps5_host_command("bluetooth",r,sizeof(r))<0);assert(ps5_host_command("wifi",r,sizeof(r))<0);assert(ps5_host_command("net nonexistent-interface",r,sizeof(r))<0);puts("host parsing/status tests PASS");return 0;}
