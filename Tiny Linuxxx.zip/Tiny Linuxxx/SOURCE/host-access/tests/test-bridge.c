#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "host_bridge.h"
static int calls;
int ps5_host_command(const char *r,char *s,size_t n) {calls++;snprintf(s,n,"OK %s\n",r);return 0;}
int main(void){
 BlockDevice b;host_bridge_init(&b);unsigned char request[512]={0},reply[8192];
 assert(b.get_sector_count(&b)==17);
 memcpy(request,"PS5CTL1\nstatus",14);
 assert(b.write_async(&b,0,request,1,0,0)==0);assert(calls==1);
 assert(b.read_async(&b,1,reply,16,0,0)==0);assert(!strcmp((char*)reply,"OK status\n"));
 assert(b.write_async(&b,1,request,1,0,0)==-1);assert(calls==1);
 assert(b.write_async(&b,0,request,2,0,0)==-1);
 memset(request,'A',512);memcpy(request,"PS5CTL1\n",8);assert(b.write_async(&b,0,request,1,0,0)==-1);
 memset(request,0,512);memcpy(request,"PS5CTL1\nfoo\nbar",15);assert(b.write_async(&b,0,request,1,0,0)==-1);
 assert(b.read_async(&b,17,reply,1,0,0)==-1);assert(b.read_async(&b,0,reply,-1,0,0)==-1);assert(calls==1);
 puts("bridge bounds/framing/response tests PASS");return 0;
}
