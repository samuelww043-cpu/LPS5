#define _GNU_SOURCE
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
static char root[128];
#define HOST_DATA_ROOT root
#define HOST_USB_ROOT root
#include "../build-app/host_control.c"
int main(void) {
 char tmp[]="/tmp/ps5-confinement-XXXXXX";assert(mkdtemp(tmp));
 snprintf(root,sizeof(root),"%s/",tmp);
 char path[256],outside[256],cmd[504],out[8192];
 snprintf(outside,sizeof(outside),"%s-outside",tmp);assert(!mkdir(outside,0700));
 snprintf(path,sizeof(path),"%slink",root);assert(!symlink(outside,path));
 const char *ops[]={"read","stat","put"};
 for(int i=0;i<3;i++){snprintf(cmd,sizeof(cmd),"%s %slink/file text",ops[i],root);if(i!=2)*strrchr(cmd,' ')=0;assert(ps5_host_command(cmd,out,sizeof(out))<0);}
 snprintf(path,sizeof(path),"%s/file",outside);assert(access(path,F_OK));
 snprintf(cmd,sizeof(cmd),"put %sfile hello",root);assert(!ps5_host_command(cmd,out,sizeof(out)));assert(ps5_host_command(cmd,out,sizeof(out))<0);
 snprintf(path,sizeof(path),"%sfinal",root);assert(!symlink("file",path));
 for(int i=0;i<3;i++){snprintf(cmd,sizeof(cmd),"%s %sfinal%s",ops[i],root,i==2?" text":"");assert(ps5_host_command(cmd,out,sizeof(out))<0);}
 snprintf(cmd,sizeof(cmd),"read %sfile",root);assert(!ps5_host_command(cmd,out,sizeof(out)));assert(!strcmp(out,"hello\n"));
 snprintf(cmd,sizeof(cmd),"stat %sfile",root);assert(!ps5_host_command(cmd,out,sizeof(out)));
 const char *bad[]={"../file","./file","/file","file/","link/../file"};
 for(int i=0;i<5;i++){snprintf(cmd,sizeof(cmd),"read %s%s",root,bad[i]);assert(ps5_host_command(cmd,out,sizeof(out))<0);}
 assert(!verify_flags(IFF_UP,1,out,sizeof(out)));assert(!verify_flags(0,0,out,sizeof(out)));assert(verify_flags(0,1,out,sizeof(out))<0);assert(verify_flags(IFF_UP,0,out,sizeof(out))<0);
 snprintf(path,sizeof(path),"%slink",root);assert(!unlink(path));snprintf(path,sizeof(path),"%sfinal",root);assert(!unlink(path));snprintf(path,sizeof(path),"%sfile",root);assert(!unlink(path));assert(!rmdir(tmp));assert(!rmdir(outside));
 puts("confinement/create preservation/network readback tests PASS");
}
