#include <stdio.h>
#include <stddef.h>
int ps5_host_command(const char *r,char *s,size_t n) {static int calls;return snprintf(s,n,"HOST_BRIDGE_TEST reply=%d request=%s\n",++calls,r);}
