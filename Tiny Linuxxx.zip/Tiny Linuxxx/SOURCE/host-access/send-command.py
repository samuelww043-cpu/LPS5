#!/usr/bin/env python3
"""Send one command through the console's existing FTP service; never retry writes."""
import argparse
import ftplib
import io
import time
import uuid

PREFIX = '/data/tiny-linux-command'

def encode_command(command):
    try:
        data = command.encode('ascii')
    except UnicodeEncodeError:
        raise ValueError('Command must use printable ASCII') from None
    if not 1 <= len(data) <= 512 or any(c < 32 or c > 126 for c in data):
        raise ValueError('Command must contain 1–512 printable ASCII bytes, without newlines')
    return data

def send(host, port, command, wait=5):
    data = encode_command(command)
    request_id = uuid.uuid4().hex
    base = PREFIX + '.' + request_id
    committed = False
    try:
        with ftplib.FTP() as ftp:
            ftp.connect(host, port, timeout=10)
            ftp.login()
            try:
                existing = bytearray()
                ftp.retrbinary('RETR ' + PREFIX + '.in', existing.extend)
            except ftplib.error_perm as exc:
                if not str(exc).startswith('550'):
                    raise
            else:
                raise RuntimeError('Terminal mailbox busy; resolve the pending request before sending another')
            packet = request_id.encode('ascii') + b'\n' + data
            ftp.storbinary('STOR ' + base + '.upload', io.BytesIO(packet))
            # Rename publishes a complete command, never a partly uploaded line.
            committed = True  # A failed rename response can have an unknown outcome.
            ftp.rename(base + '.upload', PREFIX + '.in')
            end = time.monotonic() + wait
            while time.monotonic() < end:
                for suffix in ('.accepted', '.rejected'):
                    receipt = bytearray()
                    try:
                        ftp.retrbinary('RETR ' + base + suffix, receipt.extend)
                    except ftplib.error_perm as exc:
                        if not str(exc).startswith('550'):
                            raise
                        continue
                    if suffix == '.rejected':
                        raise RuntimeError('Receiver rejected command: ' + request_id)
                    if bytes(receipt) != packet:
                        raise RuntimeError('Receipt mismatch; execution unknown: ' + request_id)
                    ftp.sendcmd('DELE ' + base + '.accepted')
                    return request_id
                time.sleep(0.1)
            raise RuntimeError('No terminal receipt; delivery/execution unknown; do not resend automatically: ' + request_id)
    except (OSError, ftplib.Error) as exc:
        state = 'delivery unknown; do not resend automatically' if committed else 'command not published'
        raise RuntimeError(f'{state}; request {request_id}: {exc}') from exc

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', help='Quote the complete shell command as one argument')
    parser.add_argument('--host', default='192.168.77.2')
    parser.add_argument('--port', type=int, default=2121)
    args = parser.parse_args()
    try:
        request_id = send(args.host, args.port, args.command)
    except (ValueError, RuntimeError) as exc:
        parser.exit(1, str(exc) + '\n')
    print('Terminal input accepted:', request_id)

if __name__ == '__main__':
    main()
