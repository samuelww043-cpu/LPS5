from pathlib import Path
import subprocess,json,hashlib,shutil,argparse
parser=argparse.ArgumentParser()
parser.add_argument("--bounded",action="store_true",help="Build a diagnostic that exits after 20 seconds")
args=parser.parse_args()
root=Path(__file__).resolve().parent;app=root/'build-app';sdk=app/'deps/ps5-payload-sdk';src=root/'sources/PS5_Vulkan/tooling/native';out=app/'build-title';out.mkdir(exist_ok=True)
def run(a):subprocess.run(list(map(str,a)),check=True,cwd=app)
cc=sdk/'bin/prospero-clang'
run([sdk/'bin/prospero-clang++','-c','-O2','-fPIE','-fno-exceptions','-fno-rtti',app/'native/app_crt.cpp','-o',out/'app_crt.o'])
run([cc,'-c','-O2',app/'native/fp.c','-o',out/'fp.o'])
flags=['-O2','-g','-Icompat','-I../sources/tinyemu-2019-12-21','-DCONFIG_RISCV_MAX_XLEN=64','-DCONFIG_VERSION="2019-12-21"','-D_GNU_SOURCE','-DAPP_INTERACTIVE','-DAPP_TITLE']
if args.bounded:flags.append('-DUI_TEST')
for name in ['main','ui','keyboard','host_bridge','host_control','host_access']:run([cc,*flags,'-c',name+'.c','-o',out/(name+'.o')])
run([cc,'-c','embed.S','-o',app/'build-ps5/embed.o'])
# Recompile RAM map with native allocation hooks; upstream remains untouched.
iomem=(root/'sources/tinyemu-2019-12-21/iomem.c').read_text()
iomem=iomem.replace('#include "iomem.h"','#include "iomem.h"\n#include "ram.h"').replace('mallocz(', 'tiny_ram_alloc(').replace('free(pr->phys_mem)', 'tiny_ram_free(pr->phys_mem)')
(out/'iomem-native.c').write_text(iomem)
run([cc,*flags,'-I'+str(app/'native'),'-c',out/'iomem-native.c','-o',out/'iomem.o'])
run([cc,*flags,'-c',app/'native/ram.c','-o',out/'ram.o'])
objs=[p for p in (app/'build-ps5').glob('*.o') if p.stem not in ['main','ui','keyboard','iomem']]+[out/'iomem.o',out/'ram.o']+[out/'host_access.o',out/'host_bridge.o',out/'host_control.o',out/'main.o',out/'ui.o',out/'keyboard.o',out/'app_crt.o',out/'fp.o']
libs=[sdk/'target/lib'/('lib'+n+'.so') for n in ['kernel','SceUserService','SceVideoOut','SceSystemService','ScePad','SceKeyboard','SceSysmodule','SceLibcInternal','c_stub_weak','SceNet']]
run([sdk/'bin/prospero-lld','-pie','-T',src/'ps5-pie.ld','--eh-frame-hdr','-e','_start','-o',out/'llvm-pie.elf',*objs,'--as-needed',*libs,sdk/'target/lib/libc.a'])
run([root/'native-tools/ps5-native-tool','link','--in',out/'llvm-pie.elf','--out',out/'eboot.elf','--stub-dir',sdk/'target/lib','--module-sdk','0x02000009','--companion-sdk','0x08050001','--file-name','eboot.elf'])
release=root/'release/PPSA99994';release.mkdir(parents=True,exist_ok=True)
run([root/'native-tools/ps5-native-tool','self','--sign','--in',out/'eboot.elf','--out',release/'eboot.bin','--magic','0x1D3D154F'])
(release/'eboot.bin').chmod(0o755)

# A fresh bundle must include the runtime, not rely on an earlier upload.
runtime=release/'sce_module/libc.prx'
expected='e6ff45d16adf687855cc3b33b0c8a4132b6504360b221e0a34c7e99fb3ba0036'
source=root/'native-tools/libc.prx'
assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
runtime.parent.mkdir(exist_ok=True);shutil.copy2(source,runtime)
assert hashlib.sha256(runtime.read_bytes()).hexdigest()==expected
manifest={str(p.relative_to(release)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(release.rglob('*')) if p.is_file() and p.name!='manifest.json'}
(release/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
