import socket,time,json,hashlib,sys
from pathlib import Path
root=Path(__file__).resolve().parent
elf=Path(sys.argv[1]);name=sys.argv[2] if len(sys.argv)>2 else 'tv-test'
r={'elf':str(elf),'sha256':hashlib.sha256(elf.read_bytes()).hexdigest(),'host':'192.168.77.2','port':9021,'started':time.time(),'sent':False}
try:
 with socket.create_connection((r['host'],r['port']),5) as s,(root/'evidence'/f'{name}.log').open('wb') as f:
  s.sendall(elf.read_bytes());r['sent']=True;s.settimeout(1);end=time.monotonic()+12;data=b''
  while time.monotonic()<end:
   try:b=s.recv(65536)
   except socket.timeout:continue
   if not b:r['closed']=True;break
   data+=b;f.write(b);f.flush();sys.stdout.buffer.write(b);sys.stdout.buffer.flush()
  r['bytes']=len(data)
except Exception as e:r['error']=str(e)
r['ended']=time.time();(root/'evidence'/f'{name}.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
