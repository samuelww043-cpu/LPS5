/* No request publication or cancellation until a documented available handler
 * and ownership-safe protocol exist. Never touch another process's request. */
#include <stdio.h>
#include "host_access.h"
void ps5_host_request_access(void) {
 puts("[ACCESS] automatic permission requests disabled; retaining existing permissions");
}
void ps5_host_cancel_access(void) { }
