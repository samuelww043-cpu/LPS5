# Tiny Linux PS5 prototype

Built and **executed on the Ethernet-connected PS5**, using its existing ELF
loader at 192.168.77.2:9021. The console returned Linux 4.15 RISC-V32, BusyBox
1.21.1, 57,764 kB guest usable memory, and the app's shell self-test success
marker. This is software emulation inside PS5 userland, not native Linux boot.

`release/tiny-linux-selftest.elf` is a standalone payload with embedded bootloader,
kernel and root disk. 64 MiB guest RAM plus emulator/embedded assets/RAM disk
and host overhead are required. The root disk is copied into RAM; writes vanish
on exit. No guest networking, filesystem sharing, console files, settings or
network configuration are modified. The old guest is for an offline prototype.

The diagnostic uses loader stdout, runs uname/memory/BusyBox checks, then exits.
If boot or shell detection fails it exits after approximately 120 seconds.
It does not provide a TV window, controller keyboard or an installed home-screen
app. The separate packaging/display worker handles that next stage.

## Build

`make` builds the PS5 payload using `deps/ps5-payload-sdk` (upstream v0.42).
`make TARGET=host` builds the same frontend for a local boot/self-test.
`compat/byteswap.h` supplies compiler byte-swap builtins missing from SDK headers.
The emulator's upstream sources remain unchanged. The SDK ZIP is checksum
verified against `8cfbc7cd5811e719eb4f0c47eea668d3dc7b40bc8ab11c4a5031d40c23ec02da`.
The PS5_Vulkan SDK bootstrap references an absent fork commit; this payload
uses the verified upstream release instead and needs no Vulkan dependencies.

## Run a diagnostic (executes on PS5)

Only run while the PS5's existing ELF loader is available and no other worker
is using it:

```
python3 test-payload.py 192.168.77.2 release/tiny-linux-selftest.elf
```

This sends once and records returned output plus hash and result in
`../evidence/ps5-payload-{console.log,result.json}`. It returns success only
when the app reports the Linux shell test passed; a successful transfer alone
is not treated as execution. Python replaces the SDK sender's unavailable
`socat` dependency using the same TCP transport. Never retry a timed-out
payload automatically: it may still be executing.

## UI integration

`app_hooks.h` specifies weak console/input/lifecycle hooks. A separate `ui.c`
can supply strong definitions, pass its object via `UI_OBJS`, and compile
`main.c` with `-DAPP_INTERACTIVE` to retain the shell after self-test. Polling
must not block; `app_should_exit()` supports clean controller-driven exit.
The embedded images are in `embed.S`, linked directly into read-only data.
A home-screen title needs the appropriate title CRT/imports, metadata, display
and installation pipeline, rather than renaming this payload to eboot.bin.

MIT frontend and TinyEMU notices apply; preserve TinyEMU's MIT-LICENSE.txt.
Linux/BusyBox guest GPL source obligations remain applicable to distribution;
this is a local development/test artifact, not a public app release.
