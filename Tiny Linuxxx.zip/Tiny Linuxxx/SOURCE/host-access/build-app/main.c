/* Tiny Linux app frontend. MIT; upstream emulator license in ../sources. */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/select.h>
#include "cutils.h"
#include "iomem.h"
#include "virtio.h"
#include "machine.h"
#include "host_bridge.h"
#ifdef APP_TITLE
#include "host_access.h"
#endif
#ifdef APP_TITLE
#include "native/ram.h"
#endif
extern unsigned char guest_bios[], guest_bios_end[];
extern unsigned char guest_kernel[], guest_kernel_end[];
extern unsigned char guest_root[], guest_root_end[];
__attribute__((weak)) void app_init(void) {}
__attribute__((weak)) void app_shutdown(void) {}
__attribute__((weak)) int app_should_exit(void) {return 0;}
__attribute__((weak)) void app_console_write(const uint8_t *buf,int len) {fwrite(buf,1,len,stdout); fflush(stdout);}
__attribute__((weak)) int app_poll_input(uint8_t *buf,int len) {
    fd_set f; struct timeval t={0,0}; FD_ZERO(&f); FD_SET(0,&f);
    if(select(1,&f,0,0,&t)>0) { int n=read(0,buf,len); return n>0?n:0; } return 0;
}
static char tail[512];
static int shell_ready, passed, sent;
#ifdef HOST_BRIDGE_TEST
static const char script[]="uname -a; head -3 /proc/meminfo; ps5ctl status; ps5ctl status; echo PS5_LINUX_\"\"SELFTEST_OK\n";
#else
static const char script[]="uname -a; cat /proc/meminfo | head -3; busybox | head -1; echo PS5_LINUX_\"\"SELFTEST_OK; export PS1='ps5user~# '; echo 'PS5 host access: ps5ctl help'; printf '\\036'\n";
#endif
static size_t script_pos;
static void output(void *opaque,const uint8_t *buf,int len) {
    (void)opaque; app_console_write(buf,len);
    for(int i=0;i<len;i++) {
        size_t n=strlen(tail);
        if(n==sizeof(tail)-1) {memmove(tail,tail+1,n);n--;}
        tail[n]=buf[i];tail[n+1]=0;
        if((strstr(tail,"/ # ") || strstr(tail,"~ # "))) shell_ready=1;
        if(strstr(tail,"\nPS5_LINUX_SELFTEST_OK\r") || strstr(tail,"\nPS5_LINUX_SELFTEST_OK\n")) passed=1;
    }
}
static int64_t sectors(BlockDevice *b) {(void)b;return (guest_root_end-guest_root)/512;}
static int disk_io(BlockDevice *b,uint64_t sector,uint8_t *buf,int n,int writing) {
    uint64_t count=sectors(b);
    if(n<0 || sector>count || (uint64_t)n>count-sector) return -1;
    if(writing) memcpy((uint8_t*)b->opaque+sector*512,buf,(size_t)n*512);
    else memcpy(buf,(uint8_t*)b->opaque+sector*512,(size_t)n*512);
    return 0;
}
static int disk_read(BlockDevice*b,uint64_t s,uint8_t*v,int n,BlockDeviceCompletionFunc*cb,void*o) {(void)cb;(void)o;return disk_io(b,s,v,n,0);}
static int disk_write(BlockDevice*b,uint64_t s,const uint8_t*v,int n,BlockDeviceCompletionFunc*cb,void*o) {(void)cb;(void)o;return disk_io(b,s,(uint8_t*)v,n,1);}
int main(void) {
#ifdef APP_TITLE
    freopen("/data/tiny-linux-title.log","w",stdout);setvbuf(stdout,NULL,_IONBF,0);
    puts("[TITLE] startup");
#endif
    app_init();
    if(app_should_exit()){app_shutdown();return 4;}
    #ifdef APP_TITLE
    ps5_host_request_access();
#endif
    puts("Tiny Linux PS5 prototype: 256 MiB RV32, local PS5 host bridge.");fflush(stdout);
    VirtMachineParams p; virt_machine_set_defaults(&p);
    p.vmc=&riscv_machine_class; p.machine_name="riscv32";
    p.vmc->virt_machine_set_defaults(&p);
    p.ram_size=256ULL<<20;
#ifdef APP_TITLE
    p.ram_size=tiny_ram_prepare_guest();
    if(!p.ram_size){puts("[RAM] no guest allocation available");app_shutdown();return 1;}
#endif
    printf("[RAM] guest selected %llu MiB\n",(unsigned long long)(p.ram_size>>20));
    p.rtc_real_time=1;
    p.cmdline="console=hvc0 root=/dev/vda rw";
    p.files[VM_FILE_BIOS].buf=guest_bios;p.files[VM_FILE_BIOS].len=guest_bios_end-guest_bios;
    p.files[VM_FILE_KERNEL].buf=guest_kernel;p.files[VM_FILE_KERNEL].len=guest_kernel_end-guest_kernel;
    BlockDevice disk={0};disk.opaque=
#ifdef APP_TITLE
    tiny_ram_alloc(guest_root_end-guest_root);
#else
    malloc(guest_root_end-guest_root);
#endif
    if(!disk.opaque) {perror("RAM disk allocation");return 1;}
    memcpy(disk.opaque,guest_root,guest_root_end-guest_root);
    disk.get_sector_count=sectors;disk.read_async=disk_read;disk.write_async=disk_write;
    BlockDevice bridge; host_bridge_init(&bridge);
    p.drive_count=2;p.tab_drive[0].block_dev=&disk;p.tab_drive[1].block_dev=&bridge;
    CharacterDevice console={0};console.write_data=output;p.console=&console;
    VirtMachine*m=virt_machine_init(&p);if(!m)return 2;
    #ifndef APP_INTERACTIVE
    time_t started=time(NULL);
#endif
    for(;;) {
        if(app_should_exit()) break;
#ifndef APP_INTERACTIVE
        if(time(NULL)-started>120) {puts("[APP] boot/self-test timed out");break;}
#endif
        virt_machine_interp(m,500000);
        if(m->console_dev && virtio_console_can_write_data(m->console_dev)) {
            uint8_t buf[128]; int max=virtio_console_get_write_len(m->console_dev);
            if(max>128)max=128;
            int n=0;
            if(shell_ready && script_pos<sizeof(script)-1) {
                n=sizeof(script)-1-script_pos;if(n>max)n=max;
                memcpy(buf,script+script_pos,n);script_pos+=n;
            } else n=app_poll_input(buf,max);
            if(n>0) virtio_console_write_data(m->console_dev,buf,n);
        }
        if(passed && !sent) {sent=1;puts("\n[APP] Linux shell self-test PASSED; disk changes disappear on exit.");fflush(stdout);
#ifndef APP_INTERACTIVE
            break;
#endif
        }
        int delay=virt_machine_get_sleep_duration(m,10);if(delay>0)usleep(delay*1000);
    }
    virt_machine_end(m);
#ifdef APP_TITLE
    tiny_ram_free(disk.opaque);
    ps5_host_cancel_access();
#else
    free(disk.opaque);
#endif
    app_shutdown();return passed?0:3;
}
