/* Explicit native operations; never passes input to a shell. */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/utsname.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <ifaddrs.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "host_control.h"
#ifdef APP_TITLE
/* SDK kernel import; avoid libc openat fallback pulling exported dup into PIE. */
extern int _openat(int, const char *, int, ...);
#define openat _openat
#endif
static unsigned long sequence;
static int fail(char *out,size_t n,const char *operation) {snprintf(out,n,"ERROR %s errno=%d (%s)\n",operation,errno,strerror(errno));return -1;}
#ifndef HOST_DATA_ROOT
#define HOST_DATA_ROOT "/data/"
#define HOST_USB_ROOT "/mnt/usb0/"
#endif
static int path_ok(const char *p) {
 size_t len=strlen(p);
 return len<240 && (strncmp(p,HOST_DATA_ROOT,strlen(HOST_DATA_ROOT))==0 || strncmp(p,HOST_USB_ROOT,strlen(HOST_USB_ROOT))==0);
}
/* Anchor at / and walk descriptor-relative: no component may be a symlink.
 * Held directory descriptors also prevent rename/symlink substitution races. */
static int confined_open(const char *path,int flags,mode_t mode) {
 if(!path_ok(path)){errno=EACCES;return -1;}
 char copy[240];snprintf(copy,sizeof(copy),"%s",path+1);
 int dir=open("/",O_RDONLY|O_DIRECTORY|O_NOFOLLOW);if(dir<0)return -1;
 char *part=copy;
 for(;;){
  char *slash=strchr(part,'/');if(slash)*slash=0;
  if(!*part||!strcmp(part,".")||!strcmp(part,"..")){close(dir);errno=EACCES;return -1;}
  int next=openat(dir,part,slash ? O_RDONLY|O_DIRECTORY|O_NOFOLLOW : flags|O_NOFOLLOW,mode);
  int saved=errno;close(dir);errno=saved;
  if(next<0||!slash)return next;
  dir=next;part=slash+1;
 }
}
static int verify_flags(short flags,int want_up,char *out,size_t n) {
 if(!!(flags&IFF_UP)==want_up)return 0;
 snprintf(out,n,"ERROR interface state verification mismatch: requested=%s observed=%s\n",want_up?"up":"down",(flags&IFF_UP)?"up":"down");return -1;
}
static int network(const char *name,const char *state,char *out,size_t n) {
 if(name&&strlen(name)>=IFNAMSIZ){snprintf(out,n,"ERROR interface name too long\n");return -1;}
 if(name){
  int fd=socket(AF_INET,SOCK_DGRAM,0);if(fd<0)return fail(out,n,"network socket");
  struct ifreq r;memset(&r,0,sizeof(r));snprintf(r.ifr_name,sizeof(r.ifr_name),"%s",name);
  if(ioctl(fd,SIOCGIFFLAGS,&r)){close(fd);return fail(out,n,"interface flags");}
  if(state){
   if(strcmp(state,"up")&&strcmp(state,"down")){close(fd);snprintf(out,n,"ERROR use net IFACE up|down\n");return -1;}
   if(!strcmp(state,"up"))r.ifr_flags|=IFF_UP;else r.ifr_flags&=~IFF_UP;
   if(ioctl(fd,SIOCSIFFLAGS,&r)){close(fd);return fail(out,n,"set interface flags");}
   if(ioctl(fd,SIOCGIFFLAGS,&r)){close(fd);return fail(out,n,"verify interface flags");}
   if(verify_flags(r.ifr_flags,!strcmp(state,"up"),out,n)){close(fd);return -1;}
  }
  close(fd);snprintf(out,n,"PS5 interface=%s flags=0x%x administrative=%s\n",name,(unsigned short)r.ifr_flags,(r.ifr_flags&IFF_UP)?"up":"down");return 0;
 }
 struct ifaddrs *list;if(getifaddrs(&list))return fail(out,n,"getifaddrs");
 size_t used=0;for(struct ifaddrs *i=list;i&&used+160<n;i=i->ifa_next){
  if(!i->ifa_addr||i->ifa_addr->sa_family!=AF_INET)continue;
  char ip[64]="?";inet_ntop(AF_INET,&((struct sockaddr_in*)i->ifa_addr)->sin_addr,ip,sizeof(ip));
  int k=snprintf(out+used,n-used,"PS5 interface=%s IPv4=%s flags=0x%x\n",i->ifa_name,ip,i->ifa_flags);if(k>0)used+=(size_t)k;
 }freeifaddrs(list);if(!used)snprintf(out,n,"PS5: no visible IPv4 interfaces\n");return 0;
}
int ps5_host_command(const char *request,char *out,size_t n) {
 if(!out||n<256)return -1;
 char line[504];if(!request||strlen(request)>=sizeof(line)){snprintf(out,n,"ERROR request too long\n");return -1;}
 snprintf(line,sizeof(line),"%s",request);sequence++;
 char *arg=strchr(line,' ');if(arg)*arg++=0;
 if(!strcmp(line,"help")){snprintf(out,n,"PS5 native host bridge (local /dev/vdb, app lifetime)\nstatus | net [IFACE [up|down]] | stat PATH | read PATH | put PATH TEXT\nFile paths: /data/ or /mnt/usb0/, new files only; no shell emulation.\nnet attempts administrative flags (requires host permission); Wi-Fi association/passwords and Bluetooth pairing/control unavailable.\n");return 0;}
 if(!strcmp(line,"status")){
  struct utsname u;int r=uname(&u);
  snprintf(out,n,"PS5 host response=%lu pid=%d uid=%d\nNative OS=%s release=%s machine=%s uname_rc=%d\nTransport=local virtio block, not Ethernet; no network listener\nStorage=file operations in /data/ and /mnt/usb0/\nWi-Fi=interface status/flags only; association unavailable\nBluetooth=unavailable (no verified native control API)\n",sequence,(int)getpid(),(int)getuid(),r?"unknown":u.sysname,r?"unknown":u.release,r?"unknown":u.machine,r);return 0;
 }
 if(!strcmp(line,"net")) {char *state=NULL;if(arg){state=strchr(arg,' ');if(state)*state++=0;}return network(arg,state,out,n);}
 if(!strcmp(line,"bluetooth")||!strcmp(line,"wifi")){snprintf(out,n,"ERROR unavailable: no verified native pairing/association API; net exposes host interface flags only\n");return -1;}
 if(!arg){snprintf(out,n,"ERROR missing path or unknown command; use help\n");return -1;}
 char *text=NULL;if(!strcmp(line,"put")){text=strchr(arg,' ');if(text)*text++=0;}
 if(!path_ok(arg)){snprintf(out,n,"ERROR path must be within /data/ or /mnt/usb0/, without traversal\n");return -1;}
 struct stat st;
 if(!strcmp(line,"stat")){int fd=confined_open(arg,O_RDONLY|O_NONBLOCK,0);if(fd<0)return fail(out,n,"open stat");int rc=fstat(fd,&st),saved=errno;close(fd);errno=saved;if(rc)return fail(out,n,"stat");snprintf(out,n,"PS5 %s bytes=%lld mode=%o\n",arg,(long long)st.st_size,(unsigned)st.st_mode);return 0;}
 if(!strcmp(line,"read")){
  int fd=confined_open(arg,O_RDONLY|O_NONBLOCK,0);if(fd<0)return fail(out,n,"open read");
  if(fstat(fd,&st)||!S_ISREG(st.st_mode)){close(fd);snprintf(out,n,"ERROR read requires a regular file\n");return -1;}
  ssize_t k=read(fd,out,n-2);int saved=errno;close(fd);errno=saved;if(k<0)return fail(out,n,"read");
  for(ssize_t i=0;i<k;i++)if((unsigned char)out[i]<32&&out[i]!='\n'&&out[i]!='\r'&&out[i]!='\t')out[i]='?';
  out[k++]='\n';out[k]=0;return 0;
 }
 if(!strcmp(line,"put")&&text){
  int fd=confined_open(arg,O_WRONLY|O_CREAT|O_EXCL,0644);if(fd<0)return fail(out,n,"create (existing files preserved)");
  size_t len=strlen(text);ssize_t k=write(fd,text,len);int sync=fsync(fd),closed=close(fd);
  if(k!=(ssize_t)len||sync||closed){snprintf(out,n,"ERROR incomplete create; inspect %s before retrying\n",arg);return -1;}
  snprintf(out,n,"PS5 created %s bytes=%zu\n",arg,len);return 0;
 }
 snprintf(out,n,"ERROR unknown command; use help\n");return -1;
}
