#ifndef PS5_HOST_CONTROL_H
#define PS5_HOST_CONTROL_H
#include <stddef.h>
int ps5_host_command(const char *request,char *response,size_t capacity);
#endif
