/* MIT. Strong definitions in a UI override weak loader-console defaults. */
#ifndef TINY_LINUX_APP_HOOKS_H
#define TINY_LINUX_APP_HOOKS_H
#include <stdint.h>
void app_init(void);
void app_shutdown(void);
int app_should_exit(void);
void app_console_write(const uint8_t *buf, int len);
/* Return 0..len bytes; never block. Input is delivered to guest virtio console. */
int app_poll_input(uint8_t *buf, int len);
#endif
