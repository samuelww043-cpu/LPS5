#include <assert.h>
#include "ui.c"
static uint32_t held;
int scePadReadState(int h,void*p){(void)h;memset(p,0,512);memcpy(p,&held,4);((unsigned char*)p)[76]=1;return 0;}
int keyboard_poll(char*b,int n){(void)b;(void)n;return 0;}
int sceVideoOutIsFlipPending(int h){(void)h;return 0;}
int sceVideoOutSubmitFlip(int a,int b,uint32_t c,int64_t d){(void)a;(void)b;(void)c;(void)d;return 0;}
int sceVideoOutGetFlipStatus(int h,uint64_t*s){(void)h;memset(s,0,128);return 0;}
static int press(unsigned b,uint8_t*out){held=b;usleep(22000);int n=app_poll_input(out,128);held=0;usleep(22000);n+=app_poll_input(out+n,128-n);return n;}
int main(void){pixels=calloc(W*H,4);pad=1;video=-1;uint8_t out[128];int n=press(0x4000,out);assert(n==1&&out[0]=='1');press(0x400,out);n=press(0x4000,out);assert(n==1&&out[0]=='!');press(0x400,out);press(0x40,out);n=press(0x4000,out);assert(n==1&&out[0]=='q');n=press(0x1000,out);assert(n==1&&out[0]=='\r');n=press(0x8000,out);assert(n==1&&out[0]==127);n=press(0x100,out);assert(n==1&&out[0]==3);n=press(0x200,out);assert(n==3&&!memcmp(out,"\033[A",3));press(9,out);assert(quit);free(pixels);puts("controller OSK navigation, shift, typing, Enter, Backspace, Ctrl-C, history and exit passed");}
