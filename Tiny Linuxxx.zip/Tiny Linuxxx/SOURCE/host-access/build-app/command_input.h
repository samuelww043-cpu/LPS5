/* FTP mailbox to terminal input; diagnostics never enter the framebuffer. */
#ifndef COMMAND_INPUT_H
#define COMMAND_INPUT_H
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#ifndef COMMAND_INPUT_PREFIX
#define COMMAND_INPUT_PREFIX "/data/tiny-linux-command"
#endif
#define COMMAND_INPUT_MAX 512
#ifdef APP_TITLE
extern int sceKernelRename(const char*,const char*);
#define command_rename sceKernelRename
#else
#define command_rename rename
#endif
static int command_id(const unsigned char*s){for(int i=0;i<32;i++)if(!((s[i]>='0'&&s[i]<='9')||(s[i]>='a'&&s[i]<='f')))return 0;return s[32]=='\n';}
static int command_input_poll(unsigned char*out,int capacity){
 if(capacity<COMMAND_INPUT_MAX+3)return 0;
 unsigned char packet[33+COMMAND_INPUT_MAX+1];
 FILE*f=fopen(COMMAND_INPUT_PREFIX ".in","rb");if(!f)return 0;
 size_t n=fread(packet,1,sizeof(packet),f);int bad=ferror(f)||n<34||n>33+COMMAND_INPUT_MAX;fclose(f);
 if(n<33||!command_id(packet))return 0;
 for(size_t i=33;i<n;i++)if(packet[i]<32||packet[i]>126)bad=1;
 char receipt[256];snprintf(receipt,sizeof(receipt),"%s.%.*s.%s",COMMAND_INPUT_PREFIX,32,packet,bad?"rejected":"accepted");
 int r=command_rename(COMMAND_INPUT_PREFIX ".in",receipt);
 if(r){static int logged;if(!logged){printf("[INPUT] claim rc=%#x\n",r);logged=1;}return 0;}
 if(bad)return 0;
 out[0]=21;out[1]='\r';memcpy(out+2,packet+33,n-33);out[n-31]='\r';return (int)n-30;
}
#endif
