/* Local guest-to-host bridge. No socket, routing change or remote listener. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "host_bridge.h"
#include "host_control.h"
#define SECTOR 512
#define COUNT 17
static uint8_t image[SECTOR*COUNT];
static int64_t sectors(BlockDevice *b) {(void)b;return COUNT;}
static int read_blocks(BlockDevice *b,uint64_t s,uint8_t *v,int n,BlockDeviceCompletionFunc *cb,void *o) {
 (void)b;(void)cb;(void)o;
 if(n<0||s>COUNT||(uint64_t)n>COUNT-s)return -1;
 memcpy(v,image+s*SECTOR,(size_t)n*SECTOR);return 0;
}
static int write_blocks(BlockDevice *b,uint64_t s,const uint8_t *v,int n,BlockDeviceCompletionFunc *cb,void *o) {
 (void)b;(void)cb;(void)o;
 if(s!=0||n!=1)return -1;
 /* Reject malformed frames before any native operation. */
 if(memcmp(v,"PS5CTL1\n",8)||!memchr(v+8,0,504))return -1;
 size_t len=strnlen((const char*)v+8,504);
 if(!len)return -1;
 for(size_t i=0;i<len;i++)if(v[8+i]<32||v[8+i]>126)return -1;
 memset(image,0,sizeof(image));
 int result=ps5_host_command((const char*)v+8,(char*)image+SECTOR,SECTOR*(COUNT-1));
 image[sizeof(image)-1]=0;
 if(!image[SECTOR])snprintf((char*)image+SECTOR,SECTOR*(COUNT-1),"ERROR host operation returned %d\n",result);
 return 0;
}
void host_bridge_init(BlockDevice *b) {
 memset(image,0,sizeof(image));memset(b,0,sizeof(*b));
 snprintf((char*)image+SECTOR,SECTOR*(COUNT-1),"PS5 native host bridge ready; run ps5ctl help\n");
 b->get_sector_count=sectors;b->read_async=read_blocks;b->write_async=write_blocks;
}
