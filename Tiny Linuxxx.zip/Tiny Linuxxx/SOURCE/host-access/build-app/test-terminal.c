#include <assert.h>
#include "ui.c"
static void feed(const char*s){while(*s)consume((unsigned char)*s++);}
int main(void){
 memset(screen,' ',sizeof(screen));
 app_console_write((const uint8_t*)"boot log\n",9);assert(!terminal_ready&&screen[0][0]==' ');
 app_console_write((const uint8_t*)"\036ps5user~# ",11);assert(terminal_ready&&!memcmp(screen[0],"ps5user~# ",10));
 memset(screen,' ',sizeof(screen));cx=cy=0;feed("abc\bD\rZ");assert(screen[0][0]=='Z'&&screen[0][2]=='D');
 feed("\033[2J\033[3;5Hq");assert(screen[2][4]=='q');feed("\033[999A\033[999D");assert(cx==0&&cy==0);
 feed("\033[999B\033[999C");assert(cx==COLS-1&&cy==ROWS-1);
 for(int i=0;i<10000;i++)consume((unsigned)(i*31)%128);
 assert(cx>=0&&cx<COLS&&cy>=0&&cy<ROWS);
 qr=qw=0;enqueue("echo test\r");assert(qw==10);for(unsigned i=0;i<qw;i++)assert(queue[i]==(unsigned char)"echo test\r"[i]);
 for(int i=0;i<2000;i++)enqueue("x");assert(qw-qr==sizeof(queue));
 puts("terminal cursor/scroll/parser bounds and input FIFO tests passed");return 0;
}
