/* GPL-3.0-or-later. Keyboard state ABI based on prospero-win's LGPL interface. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
extern int sceSysmoduleLoadModule(uint16_t);
extern int sceKeyboardInit(void);
extern int sceKeyboardOpen(int,int,int,const void*);
extern int sceKeyboardReadState(int,void*);
extern int sceKeyboardClose(int);
static int handle=-1;
static int (*read_state)(int,void*),(*close_keyboard)(int);
static int last_read=0x7fffffff,last_connected=-1;
static uint8_t old[256];static int caps;static unsigned repeat;static uint64_t deadline;
static uint64_t now_ms(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return(uint64_t)t.tv_sec*1000+t.tv_nsec/1000000;}
void keyboard_init(int user){
 memset(old,0,sizeof(old));caps=0;repeat=0;deadline=0;last_read=0x7fffffff;last_connected=-1;
 int load=sceSysmoduleLoadModule(0x106);printf("[KEYBOARD] module load=%#x; init begin\n",load);fflush(stdout);
 int ir=sceKeyboardInit();printf("[KEYBOARD] init returned=%#x\n",ir);fflush(stdout);uint8_t param[8]={0};
 handle=sceKeyboardOpen(user,0,0,param);
 read_state=sceKeyboardReadState;close_keyboard=sceKeyboardClose;
 printf("[KEYBOARD] native init=%#x open=%#x\n",ir,handle);
}
static const char* translate(unsigned k,unsigned mods,char out[2]){
 int shift=(mods&0x22)!=0,ctrl=(mods&0x11)!=0;out[0]=out[1]=0;
 if(k>=4&&k<=29)out[0]=ctrl?(char)(k-3):(char)((shift^caps?'A':'a')+k-4);
 else if(k>=30&&k<=39)out[0]=(shift?"!@#$%^&*()":"1234567890")[k-30];
 else if(k>=45&&k<=56)out[0]=(shift?"_+{}|~:\"~<>?":"-=[]\\#;'`,./")[k-45];
 else switch(k){case 40:return "\r";case 41:return "\033";case 42:return "\177";case 43:return "\t";case 44:return " ";case 73:return "\033[2~";case 74:return "\033[H";case 75:return "\033[5~";case 76:return "\033[3~";case 77:return "\033[F";case 78:return "\033[6~";case 79:return "\033[C";case 80:return "\033[D";case 81:return "\033[B";case 82:return "\033[A";}
 return out;
}
int keyboard_poll(char *buf,int max){
 if(handle<0||!read_state)return 0;uint8_t raw[96]={0},keys[256]={0};int rc=read_state(handle,raw);int connected=!rc&&raw[16]!=0;
 if(rc!=last_read||connected!=last_connected){printf("[KEYBOARD] read=%#x connected=%d\n",rc,connected);last_read=rc;last_connected=connected;}
 if(rc||!connected){memset(old,0,sizeof(old));repeat=0;return 0;}
 int count;uint32_t mods;memcpy(&count,raw+20,4);memcpy(&mods,raw+28,4);if(count<0)count=0;if(count>16)count=16;
 for(int i=0;i<count;i++){uint16_t k;memcpy(&k,raw+32+i*2,2);if(k<256)keys[k]=1;}
 int n=0;uint64_t now=now_ms();
 for(unsigned k=4;k<256;k++)if(keys[k] && (!old[k] || (repeat==k&&now>=deadline))){
  if(k==57){if(!old[k])caps=!caps;continue;}
  char out[2];const char*s=translate(k,mods,out);int len=(int)strlen(s);if(len<=max-n){memcpy(buf+n,s,len);n+=len;}
  deadline=now+(old[k]?45:400);repeat=k;
 }
 if(repeat&&!keys[repeat])repeat=0;memcpy(old,keys,256);return n;
}
void keyboard_shutdown(void){if(handle>=0&&close_keyboard)close_keyboard(handle);handle=-1;}
