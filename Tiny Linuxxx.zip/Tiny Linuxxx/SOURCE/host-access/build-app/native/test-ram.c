#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "ram.h"
static void *allocated;static int fail_allocate,fail_map,released,unmapped;
size_t sceKernelGetDirectMemorySize(void){return 256*1024*1024;}
int sceKernelAllocateDirectMemory(int64_t a,int64_t b,size_t n,size_t align,int kind,int64_t*out){assert(a==0&&b>0&&n%0x200000==0&&align==0x200000&&kind==3);if(fail_allocate)return -1;*out=0x200000;return 0;}
int sceKernelMapDirectMemory(void**p,size_t n,int prot,int flags,int64_t off,size_t align){assert(prot==3&&flags==0&&off==0x200000&&align==0x200000);if(fail_map)return -2;allocated=malloc(n);memset(allocated,0xa5,n);*p=allocated;return 0;}
int sceKernelMunmap(void*p,size_t n){assert(p==allocated&&n%0x200000==0);free(p);unmapped++;return 0;}
int sceKernelReleaseDirectMemory(int64_t off,size_t n){assert(off==0x200000&&n%0x200000==0);released++;return 0;}
int main(void){unsigned char*p=tiny_ram_alloc(64*1024*1024);assert(p);for(size_t i=0;i<64*1024*1024;i++)assert(p[i]==0);tiny_ram_free(p);assert(unmapped==1&&released==1);fail_map=1;assert(!tiny_ram_alloc(1024*1024));assert(released==2);fail_map=0;fail_allocate=1;assert(!tiny_ram_alloc(1024*1024));assert(released==2);p=tiny_ram_alloc(17);assert(p&&p[0]==0&&p[16]==0);tiny_ram_free(p);tiny_ram_free(NULL);assert(!tiny_ram_alloc(SIZE_MAX));return 0;}
