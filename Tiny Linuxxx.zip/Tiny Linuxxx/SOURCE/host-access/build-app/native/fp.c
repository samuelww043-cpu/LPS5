void ps5_fp_ieee(void){unsigned int mxcsr=0x1f80;__asm__ volatile("ldmxcsr %0"::"m"(mxcsr));__asm__ volatile("fninit");}
