/* Large guest allocations use the supported direct-memory API, outside libc heap. */
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "ram.h"
extern size_t sceKernelGetDirectMemorySize(void);
extern int sceKernelAllocateDirectMemory(int64_t,int64_t,size_t,size_t,int,int64_t*);
extern int sceKernelMapDirectMemory(void**,size_t,int,int,int64_t,size_t);
extern int sceKernelMunmap(void*,size_t);
extern int sceKernelReleaseDirectMemory(int64_t,size_t);
static struct {void *ptr; size_t size; int64_t offset;} regions[16];
static void *prepared;
static size_t prepared_size;
void *tiny_ram_alloc(size_t size) {
    if(prepared && size==prepared_size){void *p=prepared;prepared=NULL;return p;}
    if(size < 1024*1024) return calloc(1,size);
    if(size > SIZE_MAX-0x1fffff) return NULL;
    size_t rounded=(size+0x1fffff)&~(size_t)0x1fffff;
    unsigned i=0;
    while(i<16 && regions[i].ptr)i++;
    if(i==16)return NULL;
    int64_t offset=-1;void *ptr=NULL;
    int result=sceKernelAllocateDirectMemory(0,sceKernelGetDirectMemorySize(),rounded,0x200000,3,&offset);
    if(!result) {
        result=sceKernelMapDirectMemory(&ptr,rounded,3,0,offset,0x200000);
        if(result)sceKernelReleaseDirectMemory(offset,rounded);
    }
    printf("[RAM] bytes=%zu direct result=0x%x address=%p\n",rounded,result,ptr);
    if(result)return NULL;
    regions[i].ptr=ptr;regions[i].size=rounded;regions[i].offset=offset;
    memset(ptr,0,size);return ptr;
}
void tiny_ram_free(void *ptr) {
    if(!ptr)return;
    for(unsigned i=0;i<16;i++)if(regions[i].ptr==ptr){
        int result=sceKernelMunmap(ptr,regions[i].size);
        if(!result){sceKernelReleaseDirectMemory(regions[i].offset,regions[i].size);regions[i].ptr=NULL;}
        else printf("[RAM] unmap failed 0x%x\n",result);
        return;
    }
    free(ptr);
}

size_t tiny_ram_prepare_guest(void) {
 const size_t sizes[]={256UL<<20,128UL<<20,64UL<<20};
 for(unsigned i=0;i<3;i++){void *p=tiny_ram_alloc(sizes[i]);if(p){prepared=p;prepared_size=sizes[i];return sizes[i];}}
 return 0;
}
