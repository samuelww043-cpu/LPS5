#ifndef TINY_NATIVE_RAM_H
#define TINY_NATIVE_RAM_H
#include <stddef.h>
void *tiny_ram_alloc(size_t size);
size_t tiny_ram_prepare_guest(void);
void tiny_ram_free(void *ptr);
#endif
