#ifndef HOST_ACCESS_H
#define HOST_ACCESS_H
/* Requests this title's own PID via the installed HEN's existing opt-in protocol.
 * Never edits an allowlist, credentials or kernel memory. */
void ps5_host_request_access(void);
void ps5_host_cancel_access(void);
#endif
