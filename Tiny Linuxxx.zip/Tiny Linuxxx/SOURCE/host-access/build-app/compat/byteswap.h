#ifndef TINY_PS5_BYTESWAP_H
#define TINY_PS5_BYTESWAP_H
#define bswap_16 __builtin_bswap16
#define bswap_32 __builtin_bswap32
#define bswap_64 __builtin_bswap64
#endif
