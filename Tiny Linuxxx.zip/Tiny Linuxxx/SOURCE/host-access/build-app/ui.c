/* Tiny Linux TV terminal. GPL-3.0-or-later; VideoOut ABI header attribution retained. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include "app_hooks.h"
#include "videoout.h"
#include "font.h"
#include "command_input.h"
void keyboard_init(int);
int keyboard_poll(char*,int);
void keyboard_shutdown(void);
#define W 1920
#define H 1080
#define COLS 88
#define ROWS 16
#define STRIDE 10485760
extern size_t sceKernelGetDirectMemorySize(void);
extern int sceKernelAllocateDirectMemory(int64_t,int64_t,size_t,size_t,int,int64_t*);
extern int sceKernelMapDirectMemory(void**,size_t,int,int,int64_t,size_t);
extern int sceKernelMunmap(void*,size_t);
extern int sceKernelReleaseDirectMemory(int64_t,size_t);
extern int sceUserServiceInitialize(const void*);
extern int sceUserServiceGetInitialUser(int*);
extern int sceUserServiceGetForegroundUser(int*);
extern int scePadInit(void);
extern int scePadOpen(int,int,int,const void*);
extern int scePadGetHandle(int,int,int);
extern int scePadReadState(int,void*);
extern int scePadClose(int);
extern int sceSystemServiceHideSplashScreen(void);
static char screen[ROWS][COLS];
static int terminal_ready;
static int cx,cy,escape,param,first_param,saved_x,saved_y,dirty=1,quit,shift,kx,ky;
static int video=-1,pad=-1,back,pad_owned;
static int64_t physical=-1;
static unsigned char *memory;
static uint64_t serial, started;
static int capture_done;
static uint32_t previous;
static uint8_t queue[1024];static unsigned qr,qw;
static const char *keys[5]={"1234567890-=", "qwertyuiop[]", "asdfghjkl;'\\", "zxcvbnm,./` ", "!@#$%^&*()_+"};
static const char *shiftkeys[5]={"!@#$%^&*()_+","QWERTYUIOP{}","ASDFGHJKL:\"|","ZXCVBNM<>?~ ","!@#$%^&*()_+"};
static char key_character(int x,int y){return shift?shiftkeys[y][x]:keys[y][x];}
static uint32_t *pixels;
static uint64_t millis(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000+t.tv_nsec/1000000;}
static void enqueue(const char*s){while(*s && qw-qr<sizeof(queue))queue[qw++%sizeof(queue)]=(uint8_t)*s++;}
static void newline(void){cx=0;if(++cy==ROWS){memmove(screen,screen+1,(ROWS-1)*COLS);memset(screen[ROWS-1],' ',COLS);cy=ROWS-1;}}
static void consume(unsigned c){
 if(escape==1){if(c=='['){escape=2;param=0;first_param=-1;}else{escape=0;if(c=='7'){saved_x=cx;saved_y=cy;}if(c=='8'){cx=saved_x;cy=saved_y;}}return;}
 if(escape==2){if(c>='0'&&c<='9'){if(param<1000)param=param*10+c-'0';return;}if(c==';'){first_param=param;param=0;return;}if(c=='?')return;
  int n=param?param:1;
  if(c=='H'||c=='f'){cy=first_param>=0?(first_param?first_param-1:0):0;cx=param?param-1:0;}
  if(c=='A')cy-=n;if(c=='B')cy+=n;if(c=='C')cx+=n;if(c=='D')cx-=n;
  if(cx<0)cx=0;if(cx>=COLS)cx=COLS-1;if(cy<0)cy=0;if(cy>=ROWS)cy=ROWS-1;
  if(c=='J'){if(param==2)memset(screen,' ',sizeof(screen));else if(param==0){memset(screen[cy]+cx,' ',COLS-cx);for(int y=cy+1;y<ROWS;y++)memset(screen[y],' ',COLS);}}
  if(c=='K'){if(param==2)memset(screen[cy],' ',COLS);else if(param==1)memset(screen[cy],' ',cx+1);else memset(screen[cy]+cx,' ',COLS-cx);}
  if(c=='s'){saved_x=cx;saved_y=cy;}if(c=='u'){cx=saved_x;cy=saved_y;}
  escape=0;return;}
 if(c==27){escape=1;return;}if(c=='\r'){cx=0;return;}if(c=='\n'){newline();return;}
 if(c==8||c==127){if(cx)cx--;return;}if(c=='\t'){do{consume(' ');}while(cx%8);return;}
 if(c>=32&&c<127){screen[cy][cx++]=c;if(cx==COLS)newline();}
}
void app_console_write(const uint8_t*b,int n){
 fwrite(b,1,n,stdout);fflush(stdout);
 for(int i=0;i<n;i++){
  if(!terminal_ready){if(b[i]==30){terminal_ready=1;memset(screen,' ',sizeof(screen));cx=cy=escape=0;dirty=1;}continue;}
  consume(b[i]);dirty=1;
 }
}
static void rect(int x,int y,int w,int h,uint32_t c){for(int j=y;j<y+h&&j<H;j++)for(int i=x;i<x+w&&i<W;i++)if(i>=0&&j>=0)pixels[j*W+i]=c;}
static void text(int x,int y,const char*s,uint32_t c,int scale){for(;*s;s++,x+=10*scale){unsigned ch=(unsigned char)*s;if(ch>=128)ch='?';for(int j=0;j<20;j++)for(int i=0;i<10;i++)if(font[ch][j]&(1<<i))rect(x+i*scale,y+j*scale,scale,scale,c);}}
/* Altered SDL PS5 tile-address permutation; attribution in TILE-LICENSE. */
static size_t tile(unsigned x,unsigned y){return ((size_t)((y>>7)*15+(x>>7))<<16)+(((y<<4)&0x70)^((y<<5)&0xf00)^((y<<9)&0x1000)^((y<<8)&0x4000)^((x<<2)&0xc)^((x<<5)&0x380)^((x<<4)&0x400)^((x<<6)&0x800)^((x<<9)&0xa000));}
static int present(void){
 if(video<0||!memory)return -1;
 for(int i=0;i<1000&&sceVideoOutIsFlipPending(video)>0;i++)usleep(1000);
 if(sceVideoOutIsFlipPending(video)>0)return -1;
 uint8_t*b=memory+back*STRIDE;
 for(unsigned y=0;y<H;y++)for(unsigned x=0;x<W;x++)*(uint32_t*)(b+tile(x,y))=pixels[y*W+x];
 for(size_t i=0;i<STRIDE;i+=64)__asm__ volatile("clflush (%0)"::"r"(b+i):"memory");
 __asm__ volatile("sfence":::"memory");
 int r=sceVideoOutSubmitFlip(video,back,1,++serial);back^=1;
 if(!r && serial<=3){for(int i=0;i<1000&&sceVideoOutIsFlipPending(video)>0;i++)usleep(1000);uint64_t status[16]={0};int sr=sceVideoOutGetFlipStatus(video,status);printf("[UI] shown=%llu status=%#x pending=%d\n",(unsigned long long)status[3],sr,sceVideoOutIsFlipPending(video));}
 if(serial<=3||r)printf("[UI] flip %llu rc=%#x\n",(unsigned long long)serial,r);
 return r;
}
static void render(void){
 rect(0,0,W,H,0xff000000);
 for(int y=0;y<ROWS;y++){char line[COLS+1];memcpy(line,screen[y],COLS);line[COLS]=0;text(60,60+y*40,line,0xffffffff,2);}
 if(present())quit=1;
#ifdef UI_TEST
 if(!capture_done && millis()-started>5000){capture_done=1;FILE*f=fopen("/data/tiny-linux-tv.ppm","wb");if(f){fprintf(f,"P6\n%d %d\n255\n",W,H);for(int i=0;i<W*H;i++){unsigned char rgb[3]={pixels[i]>>16,pixels[i]>>8,pixels[i]};fwrite(rgb,1,3,f);}fclose(f);puts("[UI] capture saved /data/tiny-linux-tv.ppm");}}
#endif
 dirty=0;
}
void app_init(void){
 started=millis();memset(screen,' ',sizeof(screen));pixels=calloc(W*H,4);if(!pixels){quit=1;return;}
 video=sceVideoOutOpen(0xff,0,0,0);printf("[UI] VideoOut open=%#x\n",video);
 int r=video<0?video:sceKernelAllocateDirectMemory(0,sceKernelGetDirectMemorySize(),2*STRIDE,0x200000,3,&physical);
 if(!r)r=sceKernelMapDirectMemory((void**)&memory,2*STRIDE,0x33,0,physical,0x200000);
 if(!r){uint8_t attr[80]={0};struct ps5_video_out_buffer b[2]={{memory,0,{0}},{memory+STRIDE,0,{0}}};
 sceVideoOutSetBufferAttribute2(attr,UINT64_C(0x8000000000000000),0,W,H,0,0,0);
 r=sceVideoOutRegisterBuffers2(video,0,0,b,2,attr,0,0);}
 printf("[UI] register=%#x\n",r);if(r){quit=1;return;}
 sceSystemServiceHideSplashScreen();sceUserServiceInitialize(0);scePadInit();int user=-1;
 int u=sceUserServiceGetForegroundUser(&user);printf("[UI] foreground rc=%#x user=%d\n",u,user);if(u)u=sceUserServiceGetInitialUser(&user);if(!u){pad=scePadOpen(user,0,0,0);pad_owned=pad>=0;if(pad<0){printf("[UI] pad open failed=%#x; get existing handle\n",pad);pad=scePadGetHandle(user,0,0);}}
 printf("[UI] user=%d user_rc=%#x pad=%#x\n",user,u,pad);if(!u)keyboard_init(user);render();
}
int app_should_exit(void){
#ifdef UI_TEST
 if(millis()-started>20000){puts("[UI] bounded test ended");quit=1;}
#endif
 return quit;
}
int app_poll_input(uint8_t*b,int max){
 static uint64_t last,last_repeat,last_command;uint64_t now=millis();
 if(terminal_ready && now-last_command>=100){last_command=now;unsigned char command[COMMAND_INPUT_MAX+3];int cn=command_input_poll(command,(int)(sizeof(queue)-(qw-qr)));for(int i=0;i<cn;i++)queue[qw++%sizeof(queue)]=command[i];}
 if(now-last>=20){last=now;char kb[129];int kn=keyboard_poll(kb,128);kb[kn]=0;if(kn)enqueue(kb);struct {uint32_t buttons;uint8_t rest[508];}state={0};
 static int read_logged;int read_rc=pad>=0?scePadReadState(pad,&state):-1;
 if(!read_logged){printf("[UI] pad read rc=%#x connected=%d buttons=%#x\n",read_rc,state.rest[72],state.buttons);read_logged=1;}
 if(pad>=0&&read_rc==0 && !(state.buttons&0x80000000u) && state.rest[72]){uint32_t held=state.buttons,press=held&~previous;
 if(held&0xf0){if(held!=previous)last_repeat=now+350;else if(now>=last_repeat){press|=held&0xf0;last_repeat=now+90;}}
 previous=held;
 if((held&9)==9)quit=1;
 if(press&0x10)ky=(ky+4)%5;if(press&0x40)ky=(ky+1)%5;
 if(press&0x80)kx=(kx+11)%12;if(press&0x20)kx=(kx+1)%12;
 if(press&0x400)shift=!shift;
 if(press&0x4000){char s[2]={key_character(kx,ky),0};enqueue(s);}
 if(press&0x8000)enqueue("\177");if(press&0x1000)enqueue("\r");if(press&0x2000)enqueue(" ");
 if(press&0x800)enqueue("\t");if(press&0x100)enqueue("\003");if(press&0x200)enqueue("\033[A");
 if(press){printf("[UI] controller buttons=%#x queued=%u\n",press,qw-qr);dirty=1;}}
 #ifdef UI_TEST
 if(!capture_done && now-started>5000)dirty=1;
#endif
 if(dirty)render();}
 int n=0;while(n<max&&qr!=qw)b[n++]=queue[qr++%sizeof(queue)];return n;
}
void app_shutdown(void){
 keyboard_shutdown();if(pad>=0&&pad_owned)scePadClose(pad);
 if(video>=0){sceVideoOutSubmitFlip(video,-1,1,0);for(int i=0;i<2000&&sceVideoOutIsFlipPending(video)>0;i++)usleep(1000);sceVideoOutUnregisterBuffers(video,0);sceVideoOutClose(video);}
 if(memory)sceKernelMunmap(memory,2*STRIDE);if(physical>=0)sceKernelReleaseDirectMemory(physical,2*STRIDE);free(pixels);puts("[UI] shutdown complete");
}
