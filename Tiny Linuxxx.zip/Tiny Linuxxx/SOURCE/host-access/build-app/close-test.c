#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/sysctl.h>
#include <sys/user.h>
#include <stdint.h>
#include <string.h>
extern int sceSystemServiceGetAppIdOfRunningBigApp(void);
typedef struct{uint32_t appid;uint64_t unknown;uint32_t type;char title[10];char rest[60];}AppInfo;
extern int sceKernelGetAppInfo(pid_t,AppInfo*);
int main(void){int app=sceSystemServiceGetAppIdOfRunningBigApp();size_t n=0;int mib[4]={CTL_KERN,KERN_PROC,KERN_PROC_PID,140};int rc=sysctl(mib,4,0,&n,0,0);printf("[CLOSE] running=%#x query_size rc=%d errno=%d bytes=%zu\n",app,rc,errno,n);if(rc||!n||n>65536)return 1;struct kinfo_proc*p=calloc(1,n);rc=sysctl(mib,4,p,&n,0,0);AppInfo info={0};int ir=sceKernelGetAppInfo(140,&info);int own=0;for(size_t i=0;i+9<=sizeof(info);i++)if(!memcmp((char*)&info+i,"PPSA99994",9))own=1;printf("[CLOSE] read=%d errno=%d pid=%d name=%s appinfo=%#x title=%.10s appid=%#x\n",rc,errno,p->ki_pid,p->ki_comm,ir,info.title,info.appid);if(rc||ir||p->ki_pid!=140||strcmp(p->ki_comm,"eboot.bin")||!own||info.appid!=0x4018){puts("[CLOSE] identity mismatch; no signal sent");free(p);return 1;}rc=kill(140,SIGKILL);printf("[CLOSE] own failed title140 SIGKILL rc=%d errno=%d\n",rc,errno);free(p);return rc;}
