#!/usr/bin/env python3
"""One-shot official ELF-loader TCP transport; logs actual returned stdout."""
import socket,sys,time,json
from pathlib import Path
root=Path(__file__).resolve().parent
elf=Path(sys.argv[2]) if len(sys.argv)>2 else root/'build-ps5/tiny-linux.elf'
host=sys.argv[1] if len(sys.argv)>1 else '192.168.77.2'
log=root.parent/'evidence/ps5-payload-console.log'
result={'host':host,'port':9021,'started':time.time(),'sent':False,'verified':False,'elf':str(elf),'sha256':__import__('hashlib').sha256(elf.read_bytes()).hexdigest()}
try:
 with socket.create_connection((host,9021),timeout=5) as s, log.open('wb') as f:
  s.settimeout(10);s.sendall(elf.read_bytes());result['sent']=True
  s.settimeout(1);deadline=time.monotonic()+140;data=b''
  while time.monotonic()<deadline:
   try:chunk=s.recv(65536)
   except socket.timeout:continue
   if not chunk:break
   f.write(chunk);f.flush();sys.stdout.buffer.write(chunk);sys.stdout.buffer.flush();data+=chunk
   if b'[APP] Linux shell self-test PASSED' in data:result['verified']=True;break
  result['received_bytes']=len(data)
except OSError as e:result['error']=str(e)
finally:
 result['ended']=time.time();(root.parent/'evidence/ps5-payload-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
sys.exit(0 if result['verified'] else 1)
