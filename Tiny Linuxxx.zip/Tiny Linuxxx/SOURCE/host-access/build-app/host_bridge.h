#ifndef HOST_BRIDGE_H
#define HOST_BRIDGE_H
#include <stdint.h>
#include "cutils.h"
#include "virtio.h"
void host_bridge_init(BlockDevice *device);
#endif
