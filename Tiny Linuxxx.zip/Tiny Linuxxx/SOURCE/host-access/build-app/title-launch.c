#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
extern int sceUserServiceInitialize(void*);
extern int sceUserServiceGetForegroundUser(uint32_t*);
extern int sceSystemServiceGetAppIdOfRunningBigApp(void);
extern int sceSystemServiceKillApp(int,int,int,int);
typedef struct {uint32_t size,user,option;uint64_t crash;uint32_t flags;}Ctx;
extern int sceSystemServiceLaunchApp(const char*,char**,Ctx*);
int main(void){
 int s=socket(AF_INET,SOCK_STREAM,0);struct sockaddr_in a={0};a.sin_family=AF_INET;a.sin_port=htons(10101);inet_pton(AF_INET,"127.0.0.1",&a.sin_addr);
 struct timeval timeout={5,0};setsockopt(s,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
 if(connect(s,(void*)&a,sizeof(a))==0){const char*q="POST /api/v1/scan HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json\r\nContent-Length: 2\r\nConnection: close\r\n\r\n{}";send(s,q,strlen(q),0);char b[2048];int n;while((n=recv(s,b,sizeof(b),0))>0)fwrite(b,1,n,stdout);puts("");}else perror("scan connect");close(s);
 sleep(3);sceUserServiceInitialize(0);Ctx c={0};int u=sceUserServiceGetForegroundUser(&c.user);int running=sceSystemServiceGetAppIdOfRunningBigApp();printf("[LAUNCH] user_rc=%#x user=%u running=%#x\n",u,c.user,running);
 if(u)return 1;
 if(running==0x4018){int close_rc=sceSystemServiceKillApp(running,-1,0,0);printf("[LAUNCH] close own failed-test app=%#x rc=%#x\n",running,close_rc);if(close_rc)return 1;sleep(2);}
 else if(running>0){puts("[LAUNCH] different app active; leaving it alone");return 1;}
 char *argv[]={0};int rc=sceSystemServiceLaunchApp("PPSA99994",argv,&c);printf("[LAUNCH] result=%#x\n",rc);return rc<0?1:0;
}
