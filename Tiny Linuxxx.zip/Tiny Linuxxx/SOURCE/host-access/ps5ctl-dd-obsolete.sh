#!/bin/sh
# Local virtio bridge to native PS5 APIs, one operation at a time.
[ "$#" -gt 0 ] || set -- help
if ! mkdir /tmp/ps5ctl.lock 2>/dev/null; then
 echo 'ps5ctl: another operation is active' >&2; exit 1
fi
trap 'rmdir /tmp/ps5ctl.lock' EXIT HUP INT TERM
request="$*"
[ "${#request}" -le 503 ] || { echo 'ps5ctl: request too long' >&2; exit 1; }
# Explicit direct I/O avoids the guest block cache returning stale responses.
printf 'PS5CTL1\n%s\000' "$request" | dd of=/dev/vdb bs=512 count=1 conv=sync 2>/dev/null || exit 1
# The bridge is synchronous: when the write completes, the reply is ready.
dd if=/dev/vdb bs=512 skip=1 count=16 2>/dev/null | tr -d '\000'
