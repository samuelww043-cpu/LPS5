Source snapshot for the newest custom 256MiB Tiny Linux Terminal app.
App eboot SHA256: 4f521c5d4dd16b933b035674851955be340eb3b74655a5b1bec1060dbcfca053

Includes custom PS5 C/C++ app, keyboard/UI, bridge, RAM allocator, guest client,
build scripts, tests, TinyEMU source, native tooling source, SDK files and binary
runtime assets. This is the app source snapshot, not a complete source distribution
of the embedded Linux kernel, BusyBox, firmware or external LLVM toolchain.
Guest images and libc.prx are supplied as build inputs, not claimed as our source.

Build on Linux with Python3, make, and compatible LLVM/clang/lld installed.
cd SOURCE/host-access/build-app; mkdir -p build-ps5; make build-ps5/virtio.o build-ps5/pci.o build-ps5/fs.o build-ps5/cutils.o build-ps5/simplefb.o build-ps5/json.o build-ps5/machine.o build-ps5/riscv_machine.o build-ps5/softfp.o build-ps5/riscv_cpu32.o build-ps5/riscv_cpu64.o
cd ..; python3 build-title.py
The final script writes release/PPSA99994/eboot.bin and runtime. Copy the supplied
PPSA99994/sce_sys metadata into release/PPSA99994 for a complete homebrew folder.
Clean extracted source compilation and linking passed on the packaging host.
Exact byte-for-byte reproducibility is not claimed; compiler/version paths matter.

Third-party notices have been moved out of the app folder into
SOURCE/THIRD-PARTY-NOTICES; original source notices are retained.
Latest revision has local checks only; not PS5-tested. 256MiB target with fallback.
