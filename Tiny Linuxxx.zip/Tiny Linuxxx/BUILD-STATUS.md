Review fixes prepared locally — NOT deployed (2026-10-16)

Read independent final-review.md. Fixed descriptor-relative no-symlink traversal,
disabled HEN publication/cancellation entirely, and compare network IFF_UP readback.
Four sanitizer suites PASS; native SDK compile/link/package PASS after selecting
SDK libkernel _openat instead of libc fallback (fallback pulled unsupported dup export).
Native _openat behavior still needs console verification; no new console actions.
New local app: 4f521c5d4dd16b933b035674851955be340eb3b74655a5b1bec1060dbcfca053.
New pins: evidence/review-fixes/candidate-hashes.json. Prior candidate-hashes.json
is historical and does not pin current edited sources/rebuilt local release.
Backup of previous binary/source: evidence/review-fixes/before/.
Installed app remains last observed 507c28b; historical evidence below.
48 MiB stress was performed on predecessor round1, not final round2.
Original broad objective OPEN; permission/native API capability still missing.

--- Historical deployed milestone ---

Implemented, installed and live-verified partial milestone

Final app SHA256: 507c28bbbcad8b701aedb29b2c0da6904a67993ace21e6658c4fda9b0dc9e83d.
All 14 final installed + mounted file checks match release: evidence/round2/live-result.json.
No Society backend/project integration or restart was involved. Native PS5 app deployed
with staged installer and remote prior-app rollback paths in evidence/result.json.

Verified on PS5 across two launches (2026-10-16 07:04–07:10 UTC approximately):
- 256 MiB direct allocation succeeds; guest reports MemTotal 186740 KiB (~182.4 MiB),
  versus historical 57764 KiB. Extra guest RAM is not all PS5 RAM.
- 48 MiB tmpfs allocation wrote 50331648 bytes in28.0sec; used memory rose by~48MiB
  and returned after cleanup. evidence/round1/title-stress.log. No long-duration
  stability claim; no peak-load or memory-exhaustion test.
- Guest ps5ctl status produces fresh native responses 1 and2, PID changes between
  launches, reports real native FreeBSD amd64 identity, not emulator's Linux identity.
- Guest created a dedicated /data marker; guest and independent FTP readbacks agree.
- Native net listing returns actual eth0 192.168.77.2 and lo0 IPv4 data.
- Existing physical input implementation retained; not newly manually retested.
- Local tests: ASan+UBSan bridge framing/bounds, host parser/status, RAM fallback
  and cleanup pass; SDK native app builds; local guest O_DIRECT repeated replies pass.

Original objective remains OPEN:
- App UID1 cannot use SIOCGIFFLAGS (errno13 Permission denied), so interface up/down
  is exposed as an attempted native operation but NOT verified functional control.
- Installed-HEN opt-in self-PID request was staged/published once at launch; it remained
  unconsumed for10sec, did not grant root, and was cancelled only after exact own-PID
  content check. No allowlist, kernel memory or credentials were modified.
- /data/whitelist.txt was absent through existing FTP SELF interface (550).
- No verified general Wi-Fi association or Bluetooth pairing API is present in this
  SDK. Current code reports these unavailable, not success. SDK exports NetCtl names
  without argument contracts; guessing control calls is not a verified implementation.
- No virtual Ethernet route, internet access, arbitrary host shell or overwrite of
  existing OS files is provided. File put creates new files only in named data paths.

Next needed coordination: identify/provide an installed supported HEN own-title
permission handler for PPSA99994 (or an existing supported native control interface),
and actual Wi-Fi/Bluetooth API contracts for this firmware. Reviewer b remains read-only.
Candidate pins: evidence/candidate-hashes.json. Review source/build/protocol in README.md.
